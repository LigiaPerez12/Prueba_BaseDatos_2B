﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Base
{
    public partial class Form3 : Form
    {

        SqlConnection con = new SqlConnection("Server=DESKTOP-3G0D2OA ; DataBase= Banco ; Integrated Security = true");


        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        /*Declararemos las posiciones de nuestras variables */
        int posY = 0;
        int posX = 0;

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                posX = e.X;
                posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - posX);
                Top = Top + (e.Y - posY);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            
   


        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form2 NuevaVentan = new Form2();
            NuevaVentan.Show();
            Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            SqlConnection conectar = new SqlConnection("server= DESKTOP-3G0D2OA ; DataBase= Banco ; Integrated Security = true");
            conectar.Open();
            SqlCommand monto = new SqlCommand();
            SqlConnection conectanos = new SqlConnection();
            monto.Connection = conectar;

            monto.CommandText = ("select *from Tarjeta where monto = '" + label3.Text + "' ");
            conectar.Close();
        }
    } 
}


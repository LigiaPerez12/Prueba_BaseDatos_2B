﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Base
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /*Declararemos las posiciones de nuestras variables */
        int posY = 0;
        int posX = 0;
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                posX = e.X;
                posY = e.Y;
            }
            else
            {
                Left = Left + (e.X - posX);
                Top = Top + (e.Y - posY);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "9";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            txtPass.Text = txtPass.Text + "0";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            txtPass.Text = "";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Usuario UsuarioOb = new Usuario();
           
            UsuarioOb.Contrasena = this.txtPass.Text;

            if (UsuarioOb.Buscar() == true)
            {
               
                Form2 NuevaVentan = new Form2();
                NuevaVentan.Show();
                Hide();

            }
            else
            {
                MessageBox.Show(UsuarioOb.Mensaje, "Error");
            }
        }

 
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}

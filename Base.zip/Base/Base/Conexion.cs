﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Base
{
    class Conexion
    {

        public string CadenaConexion;
        protected string sql;
        //protected int resultado;
        protected SqlConnection cmn;
        protected SqlCommand commandsql;
        protected string mensaje;

        public Conexion()
        {
            this.CadenaConexion = ("Server=DESKTOP-3G0D2OA ; DataBase= Banco ; Integrated Security = true");
            this.cmn = new SqlConnection(this.CadenaConexion);

        }

        public string Mensaje
        {
            get
            {
                return this.mensaje;
            }
        }

    }
}

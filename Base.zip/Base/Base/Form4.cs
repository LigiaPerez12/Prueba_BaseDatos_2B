﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Base
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form2 NuevaVentan = new Form2();
            NuevaVentan.Show();
            Hide();
        }

        private void txtVista_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

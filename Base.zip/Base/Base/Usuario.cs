﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Base
{
    class Usuario:Conexion
    {
        public SqlCommandBuilder cmb;
        public DataSet ds = new DataSet();
        public SqlDataAdapter da;



        /*Heredamos de nuestra clase conexion*/
        
        private string contrasena;

        public Usuario()
        {
            
            contrasena = string.Empty;
            this.sql = string.Empty;
        }

       
        public string Contrasena
        {
            get { return this.contrasena; }
            set { this.contrasena = value; }
        }

        public bool Buscar()
        {
            bool resultado = false;
            this.sql = string.Format("SELECT id_usuario From Tarjeta WHERE clave='{0}'",this.contrasena);
            this.commandsql = new SqlCommand(this.sql, this.cmn);
            this.cmn.Open();
            SqlDataReader Reg = null;
            Reg = this.commandsql.ExecuteReader();

            if (Reg.Read())
            {
                resultado = true;

            }
            else
            {
                this.mensaje = "Datos Incorrectos, Verifique porfavor";
            }
            this.cmn.Close();
            return resultado;

        }

        public void consultar (string sql, string tabla)
        {

            ds.Tables.Clear();
            da = new SqlDataAdapter(sql, cmn);
            cmb = new SqlCommandBuilder(da);
            da.Fill(ds, tabla);
        }


    }


}
